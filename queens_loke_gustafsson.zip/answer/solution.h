#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

pair<ll, vector<vector<char>>> solve(ll n, vector<vector<char>> board);